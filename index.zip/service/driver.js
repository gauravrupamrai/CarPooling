const AWS = require('aws-sdk');
AWS.config.update({
    region: 'eu-west-1'
});

const util = require('../utils/util')

const dynamodb = new AWS.DynamoDB.DocumentClient();
const dynamodbTableName = 'drivers_table';
const bookStatus = false;

async function driveDetails(routeInfo){
    const carNo = routeInfo.carNo;
    const licenseNo = routeInfo.licenseNo;
    const driverName = routeInfo.driverName;
    const driveFrom = routeInfo.driveFrom;
    const driveTo = routeInfo.driveTo;
    const driveStartTime = routeInfo.driveStartTime;
    const noSeats = routeInfo.noSeats;

    if(!carNo || !licenseNo || !driverName || !driveFrom || !driveTo || !driveStartTime || !noSeats){
        return util.buildResponse(401,{
            message: 'All fields are required'
        })
    }

    const dynamoCarNo = await getCarNo(carNo);
    if(dynamoCarNo && dynamoCarNo.carNo){
        return util.buildResponse(401,{
            message: 'This car already exists in our database. Please verify'
        })
    }

    const drive = {
        carNo : carNo,
        licenseNo : licenseNo,
        driverName : driverName,
        driveFrom : driveFrom,
        driveTo : driveTo,
        driveStartTime : driveStartTime,
        noSeats : noSeats,
        bookStatus : bookStatus
    }

    const driveUpdateResponse = await driveUpdate(drive);

    if(!driveUpdateResponse){
        return util.buildResponse(503, {message: 'Server Error. Please try again later'});
    }

    return util.buildResponse(200, { carNo : carNo});

}

async function getCarNo(carNo){
    const params = {
        TableName: dynamodbTableName,
        Key: {
            carNo: carNo
        }
    }

    return await dynamodb.get(params).promise().then(response => {
        return response.Item;
    }, error => {
        console.error('There is an error in getting drive details:', error);
    })
}

async function driveUpdate(drive){
    const params = {
        TableName: dynamodbTableName,
        Item: drive
    }
    return await dynamodb.put(params).promise().then(() => {
        return true;
    }, error('There is an error saving drive details: ', error));
}

module.exports.driveDetails = driveDetails;